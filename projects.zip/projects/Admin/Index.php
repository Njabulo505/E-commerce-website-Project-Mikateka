<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_name']) || empty($_SESSION['user_name'])) {
    header('Location: login.php');
    exit;
}

$user_name = $_SESSION['user_name'];

// Fetch one record from each table
$productsQuery = "SELECT * FROM products LIMIT 1";
$usersQuery = "SELECT * FROM users LIMIT 1";
$ordersQuery = "SELECT * FROM orders LIMIT 1";
$adminUsersQuery = "SELECT * FROM admin_users LIMIT 1";

$productsResult = $conn->query($productsQuery)->fetch_assoc();
$usersResult = $conn->query($usersQuery)->fetch_assoc();
$ordersResult = $conn->query($ordersQuery)->fetch_assoc();
$adminUsersResult = $conn->query($adminUsersQuery)->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<section id="header">
    <h1 class="logo">Mikateka.com</h1>
    <ul id="nbar">
        <li><a class="active" href="index.php">HOME</a></li>
    </ul>
</section>
<div class="sidebar">
    <h2>Admin Panel</h2>
    <ul>
        <li><a href="admin_dashboard.php">Dashboard</a></li>
        <li><a href="products.php">Products</a></li>
        <li><a href="users.php">Users</a></li>
        <li><a href="orders.php">Orders</a></li>
        <li><a href="register.php">Sign up Admin user</a></li>
    </ul>
</div>
<div class="main-content">
    <h1>Welcome to the Admin Dashboard</h1>
    <div class="dashboard-cards">
        <div class="card">
            <h3>Product</h3>
            <p>ID: <?php echo $productsResult['id']; ?></p>
            <p>Name: <?php echo $productsResult['name']; ?></p>
            <p>Price: <?php echo $productsResult['price']; ?></p>
            <a href="products.php">View All Products</a>
        </div>
        <div class="card">
            <h3>User</h3>
            <p>ID: <?php echo $usersResult['id']; ?></p>
            <p>Name: <?php echo $usersResult['username']; ?></p>
            <p>Email: <?php echo $usersResult['email']; ?></p>
            <a href="users.php">View All Users</a>
        </div>
        <div class="card">
            <h3>Order</h3>
            <p>ID: <?php echo $ordersResult['id']; ?></p>
            <p>User ID: <?php echo $ordersResult['id']; ?></p>
            <p>Total: <?php echo $ordersResult['total']; ?></p>
            <a href="orders.php">View All Orders</a>
        </div>
        <div class="card">
            <h3>Admin User</h3>
            <p>ID: <?php echo $adminUsersResult['id']; ?></p>
            <p>Name: <?php echo $adminUsersResult['username']; ?></p>
            <p>Email: <?php echo $adminUsersResult['email']; ?></p>
            <a href="admin_users.php">View All Admin Users</a>
        </div>
    </div>
</div>
</body>
</html>
