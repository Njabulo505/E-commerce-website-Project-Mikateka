<?php
// edit_product.php
session_start();
include('config.php');

if (!isset($_SESSION['user_name'])) {
    header('location: login.php');
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
    } else {
        echo "Product not found!";
        exit;
    }
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_product'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $image = $_POST['image'];
    $description = $_POST['description'];
    $rating = $_POST['rating'];

    // Update product in database using prepared statements
    $stmt = $conn->prepare("UPDATE products SET name = ?, price = ?, image = ?, description = ?, rating = ? WHERE id = ?");
    $stmt->bind_param("ssssdi", $name, $price, $image, $description, $rating, $id);

    if ($stmt->execute() === TRUE) {
        header('location: products.php');
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link rel="stylesheet" href="products.css"> <!-- Link to your CSS file -->
</head>
<body>
    <h2>Edit Product</h2>
    <form action="edit_product.php" method="post" class="edit-product-form">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($product['id']); ?>">

        <label for="name">Product Name:</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>

        <label for="price">Price:</label>
        <input type="text" id="price" name="price" value="<?php echo htmlspecialchars($product['price']); ?>" required>

        <label for="image">Image URL:</label>
        <input type="text" id="image" name="image" value="<?php echo htmlspecialchars($product['image']); ?>" required>

        <label for="description">Description:</label>
        <input type="text" id="description" name="description" value="<?php echo htmlspecialchars($product['description']); ?>" required>

        <label for="rating">Rating:</label>
        <input type="number" id="rating" name="rating" value="<?php echo htmlspecialchars($product['rating']); ?>" required>

        <button type="submit" name="update_product">Update Product</button>
    </form>
</body>
</html>
