<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_name'])) {
    header('location: login.php');
    exit;
}

// Fetch orders
$sql = "SELECT * FROM orders";
$result = $conn->query($sql);
$orders = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Orders</title>
    <link rel="stylesheet" href="orders.css"> <!-- Link to your CSS file -->
</head>
<body>
<section id="header">
    <h1 class="logo">Mikateka.com</h1>
    <ul id="nbar">
        <li><a class="active" href="index.php">HOME</a></li>
    </ul>
</section>
<h1>All Orders</h1>
<?php foreach ($orders as $order): ?>
    <div class="order">
        <h2>Order ID: <?php echo $order['id']; ?></h2>
        <p>Username: <?php echo $order['username']; ?></p>
        <p>Address: <?php echo $order['address']; ?></p>
        <p>City: <?php echo $order['city']; ?></p>
        <p>Province: <?php echo $order['province']; ?></p>
        <p>Postal Code: <?php echo $order['postal_code']; ?></p>
        <p>Total: R<?php echo $order['total']; ?></p>
        <p>Order Date: <?php echo $order['order_date']; ?></p>
        <p>Delivery Method: <?php echo $order['delivery_method']; ?></p>
        <p>Status: <?php echo $order['status']; ?></p>
        
        <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?> <!-- Only show update form if user is admin -->
        <form action="update_order_status.php" method="post">
            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
            <select name="status">
                <option value="pending" <?php if ($order['status'] == 'pending') echo 'selected'; ?>>Pending</option>
                <option value="processing" <?php if ($order['status'] == 'processing') echo 'selected'; ?>>Processing</option>
                <option value="complete" <?php if ($order['status'] == 'complete') echo 'selected'; ?>>Complete</option>
            </select>
            <button type="submit">Update Status</button>
        </form>
        <?php endif; ?>
        
        <h3>Order Items:</h3>
        <ul>
            <?php
            // Fetch order items
            $sql = "SELECT * FROM order_items WHERE order_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('i', $order['id']);
            $stmt->execute();
            $result = $stmt->get_result();
            $order_items = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();

            foreach ($order_items as $item): ?>
            <li>Product ID: <?php echo $item['product_id']; ?>, Price: R<?php echo $item['price']; ?>, Quantity: <?php echo $item['quantity']; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endforeach; ?>
</body>
</html>

<?php $conn->close(); ?>
