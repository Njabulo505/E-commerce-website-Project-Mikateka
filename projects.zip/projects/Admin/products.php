<?php
// admin_products.php
session_start();
include('config.php');

if (!isset($_SESSION['user_name'])) {
    header('location: login.php');
    exit;
}

// Delete product
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM products WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Fetch products
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Products</title>
    <link rel="stylesheet" href="products.css"> <!-- Link to your CSS file -->
</head>
<body>
<section id="header">
    <h1 class="logo">Mikateka.com</h1>
    <ul id="nbar">
        <li><a class="active" href="index.php">HOME</a></li>
    </ul>
</section>
    <h1>Products</h1>
    <ul class="product-list">
        <?php while ($row = $result->fetch_assoc()): ?>
        <li class="product-item">
            <div class="product-info">
                <img src="<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>" class="product-image">
                <div class="product-details">
                    <span class="product-name"><?php echo $row['name']; ?></span>
                 <p>Price: R   <span class="product-price"><?php echo $row['price']; ?></span></p>
                </div>
            </div>
            <div class="product-actions">
                <a href="products.php?delete=<?php echo $row['id']; ?>" class="delete-button">Delete</a>
                <a href="edit_product.php?id=<?php echo $row['id']; ?>" class="edit-button">Edit</a>
            </div>
        </li>
        <?php endwhile; ?>
    </ul>

    <!-- Button to go to Add Product page -->
    <h2>Add New Product</h2>
    <a href="add_product.php" class="add-product-button">Add Product</a>
</body>
</html>

<?php $conn->close(); ?>
