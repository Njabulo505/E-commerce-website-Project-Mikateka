<?php
session_start();
include('config.php');

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header('location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['order_id']) && isset($_POST['status'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];
    
    $sql = "UPDATE orders SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('si', $status, $order_id);
    $stmt->execute();
    $stmt->close();
    
    header('location: orders.php');
    exit;
}
?>
