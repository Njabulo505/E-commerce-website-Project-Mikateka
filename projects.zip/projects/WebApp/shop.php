<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Login</title>
<meta charset="UTF-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
<link rel = "stylesheet" type = "text/css" href = "style.css"> 
</head>
<body>
    <section id="header">
        <h1 class="logo">Mikateka.com</h1>
        <ul id="nbar">
        <li><a href="index.php">HOME</a></li>
        <li><a class="active" href="shop.html">SHOP</a></li>
        <li><a href="about.html">ABOUT US</a></li>
        <li><a href="contact.html">CONTACT</a></li>
        </ul>
    </section>
    <section id="products" class="p-section">
    <h2>Products</h2>
    <div class="content-wrapper">
        <?php
         session_start();
         include('config.php');

        $sql = "SELECT id, name, image, description, rating, price FROM products";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                echo '<div class="content">
                        <a href="products.php?id=' . $row["id"] . '">
                            <div class="row">
                                <div class="row-img">
                                    <img src="' . $row["image"] . '" alt="' . $row["name"] . '">
                                </div>
                                <h3>' . $row["name"] . '</h3>
                                <div class="stars">';
                                    for ($i = 0; $i < 4; $i++) {
                                        echo '<a href="#"><i class="fa-solid fa-star"></i></a>';
                                    }
                                    echo '<a href="#">' . $row["rating"] . '/5</a>
                                </div>
                                <div class="row-in">
                                    <div class="row-left">
                                    <a href="products.php?action=add&id=' . $row['id'] . '">
                                    Add to Cart
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </a>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>';
            }
        } else {
            echo "0 results";
        }
        $conn->close();
        ?>
    </div>
</section>
<footer>
 <p>&copy; 2024 Mikateka Primary School. All rights reserved.</p>
    </footer>
</body>
</html>